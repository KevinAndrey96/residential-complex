<?php


namespace App\UseCases\Contracts\Services;


interface StoreServiceUseCaseInterface
{

}
