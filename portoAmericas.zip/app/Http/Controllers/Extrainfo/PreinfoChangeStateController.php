<?php

namespace App\Http\Controllers\Extrainfo;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PreinfoChangeStateController extends Controller
{
    public function preinfo()
    {
        return view('extrainfo.preinfo');
    }
}
