<?php $__env->startSection('content'); ?>

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('bookingSuccess')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('bookingSuccess')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('dayFail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('dayFail')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('dateFail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('dateFail')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('quantityFail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('quantityFail')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('personsFail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('personsFail')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('limitPerDayFail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('limitPerDayFail')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="card">
        <div class="card-header">
            Servicios de clubhouse
        </div>
        <div class="card-body container-fluid">
            <div class="justify-content-center" >
                <?php if(Auth::user()->resident->status == 'Deshabilitado'): ?>
                    <div class="col-auto mt-5">
                        <h3 style="color:#ff0000">
                            Estimado residente usted no puede hacer uso de los servicios de clubhouse
                        </h3>
                    </div>
                <?php else: ?>
                    <div class="col-auto mt-5">
                    <table class="table table-responsive datatable" id="datatable">
                        <thead class="thead-light">
                        <tr>
                            <th></th>
                            <th style="text-align: center; padding:10px;">Título</th>
                            <th style="text-align: center; padding:10px;">Descripción</th>
                            <th style="text-align: center; padding:10px;">Capacidad</th>
                            <th style="text-align: center; padding:10px;">Inicio</th>
                            <th style="text-align: center; padding:10px;">Cierre</th>
                            <th style="text-align: center; padding:10px;">Franja</th>
                            <th style="text-align: center; padding:10px;">Días hábiles</th>
                            <th style="text-align: center; padding:10px;">Estado</th>
                            <th style="text-align: center; padding:10px;">Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img class="" style="width: 150px; border-radius: 5%;"  onError="this.onerror=null;this.src='/assets/images/imagen-fallo.jpg';" src="<?php echo e($service->gallery); ?>">
                                    </td>
                                    <td style="text-align: center; padding:10px;"><?php echo e($service->title); ?></td>
                                    <td style="text-align: center; padding:10px;"><?php echo e($service->description); ?></td>
                                    <td style="text-align: center; padding:10px;"><?php echo e($service->capacity); ?> personas</td>
                                    <td style="text-align: center; padding:10px;"><?php echo e($service->start); ?></td>
                                    <td style="text-align: center; padding:10px;"><?php echo e($service->final); ?></td>
                                    <td style="text-align: center; padding:10px;"><?php echo e($service->strip); ?> minutos</td>
                                    <td style="text-align: center; padding:10px;">
                                        <ul>
                                            <?php if($service->monday == 1): ?> <li> Lunes </li> <?php endif; ?>
                                            <?php if($service->tuesday == 1): ?> <li> Martes </li> <?php endif; ?>
                                            <?php if($service->wednesday == 1): ?> <li> Miércoles </li> <?php endif; ?>
                                            <?php if($service->thursday == 1): ?> <li> Jueves </li> <?php endif; ?>
                                            <?php if($service->friday == 1): ?> <li> Viernes </li> <?php endif; ?>
                                            <?php if($service->saturday == 1): ?> <li> Sábado </li> <?php endif; ?>
                                            <?php if($service->sunday == 1): ?> <li> Domingo </li> <?php endif; ?>
                                        </ul>
                                    </td>
                                    <td style="text-align: center; padding:10px;">
                                        <?php if($service->state == 1): ?>
                                            Habilitado
                                        <?php else: ?>
                                            Deshabilitado
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: center; padding:10px;">
                                        <?php if($service->state == 1): ?>
                                        <div class="btn-group">
                                            <form method="POST" action="/bookings/schedule">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">
                                                <input style="padding-right: 45%; width:50%; text-align: center;" class="btn btn-success btn-block" type="submit" value ="Reservar">
                                            </form>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/bookings/create.blade.php ENDPATH**/ ?>