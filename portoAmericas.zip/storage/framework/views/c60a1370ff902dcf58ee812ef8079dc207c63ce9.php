
<?php $__env->startSection('content'); ?>



<div class="card">
    <div class="card-header">
       Administradores - Recepcionistas
    </div>
    <div class="card-body container-fluid">
        <div class="row justify-content-center" >
            <div class="col-auto mt-5">
                <table class="table table-bordered table-responsive text-center" id="datatable"  width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th style="text-align: center; padding:10px;">Id</th>
                            <th style="text-align: center; padding:10px;">Nombre</th>
                            <th style="text-align: center; padding:10px;">Telefono</th>
                            <th style="text-align: center; padding:10px;">Email</th>
                            <th style="text-align: center; padding:10px;">Documento</th>
                            <th style="text-align: center; padding:10px;">Rol</th>
                            <th style="text-align: center; padding:10px;">Acción</th>
                            
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $adminreceps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminrecep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="text-align: center; padding:10px"><?php echo e($adminrecep->id); ?></td>
                                <td style="text-align: center; padding:10px"><?php echo e($adminrecep->name); ?></td>
                                <td style="text-align: center; padding:10px"><?php echo e($adminrecep->phone); ?></td>
                                <td style="text-align: center; padding:10px"><?php echo e($adminrecep->email); ?></td>
                                <td style="text-align: center; padding:10px"><?php echo e($adminrecep->document); ?></td>
                                <td style="text-align: center; padding:10px">
                                <?php if($adminrecep->role == 'Administrator'): ?>
                                    Administrador
                                <?php else: ?> 
                                    Recepcionista
                                <?php endif; ?>
                                </td>
                                <td style="text-align: center; padding:10px;">
                                    <div class="btn-group">
                                        <form method="POST" action="/adminrecep/edit">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value=<?php echo e($adminrecep->id); ?>>
                                            <input style="margin:3px; width:50%;" class="btn btn-warning btn-block" type="submit" value ="Editar">
                                        </form>
                                        <form method="POST" action="/adminrecep/delete">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value=<?php echo e($adminrecep->id); ?>>
                                            <input style="margin:3px; width:50%;" class="btn btn-danger btn-block" type="submit" onclick="return confirm('¿Esta seguro que quiere borrar este usuario?');" value ="Eliminar">
                                        </form>
                                    </div>
                                </td>
                            
                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/adminreceps/index.blade.php ENDPATH**/ ?>