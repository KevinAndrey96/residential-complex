<?php $__env->startSection('content'); ?>



<div class="card">
    <div class="card-header">
        <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
        Administradores - Recepcionistas
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->hasRole('Administrator')): ?>
        Recepcionistas
        <?php endif; ?>
    </div>
    <div class="card-body container-fluid">
        <div class="justify-content-center" >
            <div style="width: 100%; padding-left: -10px;">
            <div class="col-auto mt-5">
                <div class="table-responsive">
                <table id="datatable" class="table table-striped table-hover dt-responsive display nowrap" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th style="text-align: center; padding:10px;">Id</th>
                            <th style="text-align: center; padding:10px;">Nombre</th>
                            <th style="text-align: center; padding:10px;">Telefono</th>
                            <th style="text-align: center; padding:10px;">Email</th>
                            <th style="text-align: center; padding:10px;">Documento</th>
                            <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                            <th style="text-align: center; padding:10px;">Rol</th>
                            <?php endif; ?>
                            <th style="text-align: center; padding:10px;">Acción</th>
                        </tr>
                    </thead>
                    <tbody class="justify-content-center text-center">
                    <?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->adminrecep->document && $user->role): ?>
                                <tr>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->id); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->name); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->phone); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->email); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->adminrecep->document); ?></td>
                                <td style="text-align: center; padding:10px;">
                                <?php if($user->role == 'Administrator'): ?>
                                    Administrador
                                <?php else: ?>
                                    Recepcionista
                                <?php endif; ?>
                                </td>
                                <td style="text-align: center; padding:10px;">
                                    <div class="btn-group">
                                        <a style="margin:3px; width:50%; color:white;" class="btn btn-warning btn-block" href="/adminrecep/edit/<?php echo e($user->id); ?>">Editar</a>
                                        <form method="POST" action="/adminrecep/delete">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value=<?php echo e($user->id); ?>>
                                            <input style="margin:3px; width:50%;" class="btn btn-danger btn-block" type="submit" onclick="return confirm('¿Esta seguro que quiere borrar este usuario?');" value ="Eliminar">
                                        </form>
                                    </div>
                                </td>

                            </tr>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Administrator')): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->adminrecep->document && $user->role && $user->role == 'Receptionist'): ?>
                            <tr>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->id); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->name); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->phone); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->email); ?></td>
                                <td style="text-align: center; padding:10px;"><?php echo e($user->adminrecep->document); ?></td>
                                <td style="text-align: center; padding:10px;">
                                    <div class="btn-group">
                                        <a style="margin:3px; width:50%; color:white;" class="btn btn-warning btn-block" href="/adminrecep/edit/<?php echo e($user->id); ?>">Editar</a>
                                        <form method="POST" action="/adminrecep/delete">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value=<?php echo e($user->id); ?>>
                                            <input style="margin:3px; width:50%;" class="btn btn-danger btn-block" type="submit" onclick="return confirm('¿Esta seguro que quiere borrar este usuario?');" value ="Eliminar">
                                        </form>
                                    </div>
                                </td>

                            </tr>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/adminreceps/index.blade.php ENDPATH**/ ?>