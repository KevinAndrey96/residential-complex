<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-header">
            <?php if(auth()->check() && auth()->user()->hasRole('Resident')): ?>
            Mis reservas
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('Administrator')): ?>
            Reservas
            <?php endif; ?>
        </div>
        <div class="card-body container-fluid">
            <div class="justify-content-center" >
                <p style="font-size: 20px">Seleccione un servicio:</p>
                <div class="col-auto mt-5">
                    <div style="width: 100%; padding-left: -10px;">
                        <div class="table-responsive">
                            <table id="datatable" class="table dt-responsive display nowrap" width="100%" cellspacing="0">

                            <tbody>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center">
                                            <a style="width:40%; padding: 15px; margin:0px; background-color:#B74438 !important;"  class="btn btn-danger" href="/detailBooking/<?php echo e($service->id); ?>"><?php echo e($service->title); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/bookings/index.blade.php ENDPATH**/ ?>