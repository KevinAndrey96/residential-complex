<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('usedApt')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('usedApt')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('updaresisuccess')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('updaresisuccess')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('residentSuccess')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('residentSuccess')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('residentFail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('residentFail')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="card">
        <div class="card-header">
            Residentes
        </div>
        <div class="card-body container-fluid">
            <div class="row justify-content-center" >
                <div class="col-auto mt-5">
                    <div style="width: 100% !important;">
                        <table class="table table-bordered table-responsive datatable justify-content-center text-center" id="datatable">
                        <thead class="thead-light">
                        <tr>
                            <th style="text-align: center; padding:10px;">Id</th>
                            <th style="text-align: center; padding:10px;">Nombre</th>
                            <th style="text-align: center; padding:10px;">Telefono</th>
                            <th style="text-align: center; padding:10px;">Email</th>
                            <th style="text-align: center; padding:10px;">Torre</th>
                            <th style="text-align: center; padding:10px;">Apartamento</th>
                            <th style="text-align: center; padding:10px;">Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->role == 'Resident'): ?>
                                    <tr>
                                        <td style="text-align: center; padding:10px;"><?php echo e($user->id); ?></td>
                                        <td style="text-align: center; padding:10px;"><?php echo e($user->name); ?></td>
                                        <td style="text-align: center; padding:10px;"><?php echo e($user->phone); ?></td>
                                        <td style="text-align: center; padding:10px;"><?php echo e($user->email); ?></td>
                                        <td style="text-align: center; padding:10px;"><?php echo e($user->resident->tower); ?></td>
                                        <td style="text-align: center; padding:10px;"><?php echo e($user->resident->apt); ?></td>
                                        <td style="text-align: center; padding:10px;" class="">
                                            <div id="endis" style="display: block; margin:3px;" >
                                                <?php if($user->resident->status == 'Habilitado'): ?>
                                                    <input type="checkbox" data-onstyle="success"
                                                           checked
                                                           data-on="Habilitado"
                                                           data-size="xs"
                                                           data-toggle="toggle"
                                                           name="togglestatus<?php echo e($user->id); ?>" id="togglestatus<?php echo e($user->id); ?>"
                                                           onchange="getStatus(<?php echo e($user->id); ?>)">
                                                <?php elseif($user->resident->status == 'Deshabilitado'): ?>
                                                    <input type="checkbox" data-onstyle="success"
                                                           data-off="Deshabilitado"
                                                           data-size="xs"
                                                           data-toggle="toggle"
                                                           name="togglestatus<?php echo e($user->id); ?>" id="togglestatus<?php echo e($user->id); ?>"
                                                           onchange="getStatus(<?php echo e($user->id); ?>)">
                                                <?php endif; ?>
                                            </div>
                                                <div class="btn-group">
                                                    <form method="POST" action="/residents/edit">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value=<?php echo e($user->id); ?>>
                                                        <input style="margin:3px; width:50%;" class="btn btn-warning btn-block" type="submit" value ="Editar">
                                                    </form>
                                                    <form method="POST" action="/residents/delete">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value=<?php echo e($user->id); ?>>
                                                        <input style="margin:3px; width:50%;" class="btn btn-danger btn-block" type="submit" onclick="return confirm('Si borra el residente el apartamento de este se reseteara y no tendrá dueño, esta seguro?');" value ="Eliminar">
                                                    </form>
                                                </div>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                        <form id="form-status" name="form-status" method="post" action="/changeStatusResident">
                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" id="id">
                            <input type="hidden" name="status" id="status">
                        </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function getStatus(id)
        {
            var toggle = document.getElementById("togglestatus"+id);
            var status = document.getElementById("status");
            var form = document.getElementById("form-status");
            var user_id = document.getElementById("id");

            if(toggle.checked == true){
                status.value = 'Habilitado';
            } else {
                status.value = 'Deshabilitado';
            }
            user_id.value = id;
            form.submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/residents/index.blade.php ENDPATH**/ ?>