
<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <?php if(Session::has('adminrecepSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('adminrecepSuccess')); ?>

        </div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">
      Editar Adiministradores - Recepcionistas
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('/adminrecep/update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="name">Nombre: </label>
                <input class="form-control" type="text" name="name" id="name" value="<?php echo e($adminrecep->name); ?>">
            </div>
            <div class="form-group">
                <label for="phone">Teléfono: </label>
                <input class="form-control" type="number" name="phone" id="phone" value="<?php echo e($adminrecep->phone); ?>">
            </div>
            <div class="form-group">
                <label for="email">Email: </label>
                <input class="form-control" type="email" name="email" id="email" value="<?php echo e($adminrecep->email); ?>">
            </div>
            <div class="form-group">
                <label for="document_number">Número de documento: </label>
                <input class="form-control" type="text" name="document" id="document" value="<?php echo e($adminrecep->document); ?>">
            </div>
            <div class="form-group">
                <label for="role">Rol: </label>
                <select class="form-control" name="role" id="role">
                    <option value="<?php echo e($adminrecep->role); ?>" selected disabled>
                        <?php if($adminrecep->role == "Administrator"): ?>
                            Administrador
                        <?php else: ?>
                            Recepcionista
                        <?php endif; ?>
                    </option>
                    <option value="Administrator">Administrador</option>
                    <option value="Receptionist">Recepcionista</option>
                </select>
            </div> 
            <div class="form-group">
                <label for="password">Contraseña: </label>
                <input class="form-control" type="password" name="password" id="password">
            </div>
            <input type="hidden" name="id" value="<?php echo e($id); ?>">
            <input class="btn btn-secondary" style="width:300px, background-color:#B74438 !important; float:right" type="submit" value="Modificar">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/adminreceps/edit.blade.php ENDPATH**/ ?>