<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('cancelSuccess')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('cancelSuccess')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('cancelFail')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('cancelFail')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="card">
        <div class="card-header">
            Reservaciones hechas
        </div>
        <div class="card-body container-fluid">
            <div class="justify-content-center" >
                <div class="col-auto mt-5">
                    <div style="width: 100%; padding-left: -10px;">
                        <div class="table-responsive">
                            <table id="datatable" class="table table-striped table-hover dt-responsive display nowrap" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th style="text-align: center; padding:10px;">Número de reserva</th>
                                    <?php if(auth()->check() && auth()->user()->hasAnyRole('Administrator|Receptionist')): ?>
                                    <th style="text-align: center; padding:10px;">Residente</th>
                                    <?php endif; ?>
                                    <th style="text-align: center; padding:10px;">Cantidad de personas</th>
                                    <th style="text-align: center; padding:10px;">Día</th>
                                    <th style="text-align: center; padding:10px;">Fecha</th>
                                    <th style="text-align: center; padding:10px;">Hora</th>
                                    <th style="text-align: center; padding:10px;">Estado</th>
                                    <?php if(auth()->check() && auth()->user()->hasRole('Resident')): ?>
                                    <th style="text-align: center; padding:10px;">Acción</th>
                                    <?php endif; ?>
                                    <?php if(auth()->check() && auth()->user()->hasAnyRole('Administrator|Receptionist')): ?>
                                    <th style="text-align: center; padding:10px;">Cambiar estado</th>
                                    <?php endif; ?>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center; padding:10px;"> <?php echo e($booking->id); ?></td>
                                        <?php if(auth()->check() && auth()->user()->hasAnyRole('Administrator|Receptionist')): ?>
                                        <td style="text-align: center; padding:10px;"> <?php echo e($booking->user->name); ?></td>
                                        <?php endif; ?>
                                        <td style="text-align: center; padding:10px;"><?php echo e($booking->quantity); ?></td>
                                        <td style="text-align: center; padding:10px;">
                                            <?php if($booking->day == 'monday'): ?>
                                                Lunes
                                            <?php elseif($booking->day == 'tuesday'): ?>
                                                Martes
                                            <?php elseif($booking->day == 'wednesday'): ?>
                                                Miércoles
                                            <?php elseif($booking->day == 'thursday'): ?>
                                                Jueves
                                            <?php elseif($booking->day == 'friday'): ?>
                                                Viernes
                                            <?php elseif($booking->day == 'saturday'): ?>
                                                Sábado
                                            <?php elseif($booking->day == 'sunday'): ?>
                                                Domingo
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center; padding:10px;"><?php echo e($booking->date); ?></td>
                                        <td style="text-align: center; padding:10px;"><?php echo e($booking->hour); ?></td>
                                        <td style="text-align: center; padding:10px;">
                                            <?php if($booking->state == 'Reservada'): ?>
                                                <p style="background-color:#51C70E; color:white; padding:5px; border-radius: 5px;"><?php echo e($booking->state); ?></p>
                                            <?php elseif($booking->state == 'Tomada'): ?>
                                                <p style="background-color:#2084D8; color:white; padding:5px; border-radius: 5px;"><?php echo e($booking->state); ?></p>
                                            <?php elseif($booking->state == 'Cancelada'): ?>
                                                <p style="background-color:#C70E0E; color:white; padding:5px; border-radius: 5px;"><?php echo e($booking->state); ?></p>
                                            <?php elseif($booking->state == 'Perdida'): ?>
                                                <p style="background-color:#2D4152; color:white; padding:5px; border-radius: 5px;"><?php echo e($booking->state); ?></p>
                                            <?php elseif($booking->state == 'En espera'): ?>
                                                <p style="background-color:#EFBD02; color:white; padding:5px; border-radius: 5px;"><?php echo e($booking->state); ?></p>
                                            <?php endif; ?>
                                        </td>
                                        <?php if(auth()->check() && auth()->user()->hasRole('Resident')): ?>
                                        <td>
                                            <?php if($booking->state == 'Reservada'): ?>
                                            <center>
                                                <form method="post" action="/booking/cancel">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                                                    <input type="submit" class="btn btn-danger" onclick="return confirm('¿Esta seguro que quiere cancelar esta reservación?');" value="Cancelar">
                                                </form>
                                            </center>
                                            <?php endif; ?>
                                        </td>
                                        <?php endif; ?>
                                        <?php if(auth()->check() && auth()->user()->hasAnyRole('Administrator|Receptionist')): ?>
                                        <td style="text-align: center; padding:10px;">
                                            <?php if( $booking->state == 'Reservada' || $booking->state == 'En espera' ): ?>
                                            <div style="margin:0px auto" class="">
                                            <select class="form-control-sm" name="state<?php echo e($booking->id); ?>" id="state<?php echo e($booking->id); ?>"  onchange="getState(<?php echo e($booking->id); ?>)">
                                                <option value="Tomada" selected disabled></option>
                                                <option value="En espera">En espera</option>
                                                <option value="Tomada">Tomada</option>

                                            </select>
                                            </div>
                                                <?php endif; ?>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <form method="post" action="/bookings/changeState" id="form-state">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="newState" id="newState">
                                <input type="hidden" name="bookingID" id="bookingID">
                            </form>
                        </div>

                    </div>
                    <a style="float:right; color:white; margin-top:20px;" class="btn btn-danger" href="/updateBookingStates">Actualizar estados</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function getState(id)
        {

            stateSelect = document.getElementById('state'+id);
            newState = document.getElementById('newState');
            bookingID = document.getElementById('bookingID');
            form = document.getElementById('form-state');
            newState.value = stateSelect.value;
            bookingID.value = id;
            form.submit();
            console.log(newState.value);

        }
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\portoAmericas\resources\views/bookings/detailBooking.blade.php ENDPATH**/ ?>