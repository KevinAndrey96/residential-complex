<?php $__env->startSection('content'); ?>



<div class="card">
    <div class="card-header">
        Configuraciones
    </div>
    <div class="card-body container-fluid">
        <div class="row justify-content-center" >
            <div class="col-auto mt-5">
                <table class="table table-bordered table-responsive display responsive no-wrap" id="datatable" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th style="text-align: center; padding:10px;">Nombre</th>
                            <th style="text-align: center; padding:10px;">Número de torres</th>
                            <th style="text-align: center; padding:10px;">Número de interiores</th>
                            <th style="text-align: center; padding:10px;">Número de apartamentos</th>
                            <th style="text-align: center; padding:10px;">Glosario</th>
                            <th style="text-align: center; padding:10px;">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align: center; padding:10px;"><?php echo e($setting->name); ?></td>
                            <td style="text-align: center; padding:10px;"><?php echo e($setting->num_tower); ?></td>
                            <td style="text-align: center; padding:10px;"><?php echo e($setting->num_int); ?></td>
                            <td style="text-align: center; padding:10px;"><?php echo e($setting->num_apt); ?></td>
                            <td style="text-align: center; padding:10px;"><?php echo e($setting->glossary); ?></td>
                            <td style="text-align: center; padding:10px;">
                                <div class="btn-group">
                                    <form method="POST" action="/setting/edit">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value=<?php echo e($setting->id); ?>>
                                        <input style="margin:3px; width:50%;" class="btn btn-warning btn-block" type="submit" value ="Editar">
                                    </form>
                                    <form method="POST" action="/setting/delete">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value=<?php echo e($setting->id); ?>>
                                        <input style="margin:3px; width:50%;" class="btn btn-danger btn-block" type="submit" onclick="return confirm('¿Esta seguro que quiere borrar este usuario?');" value ="Eliminar">
                                    </form>
                                </div>


                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/settings/index.blade.php ENDPATH**/ ?>