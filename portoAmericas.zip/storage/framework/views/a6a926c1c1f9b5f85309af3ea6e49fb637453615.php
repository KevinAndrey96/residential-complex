<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Crear Reservación
        </div>
        <div class="card-body">
            <form action="/bookings/store" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="quantity">Cantidad de personas: </label>
                    <input class="form-control" type="number" name="quantity" id="quantity" min="1" required>
                </div>
                <div class="form-group">
                    <label for="hour">Hora para iniciar el servicio de <?php echo e($service->title); ?> (tenga en cuenta que el servicio dura <?php echo e($service->strip); ?> minutos): </label>
                    <select class="form-control" name="hour" id="hour">
                        <?php $__currentLoopData = $hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hour); ?>" selected><?php echo e($hour); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date"> Seleccione la fecha en la cual hará uso del servicio de <?php echo e($service->title); ?></label>
                    <input class="form-control" type="date" name="date" id="date" required>
                </div>
                <input type="hidden" name="state" id="state" value="Reservada">
                <input type="hidden" name="service_id" id="service_id" value="<?php echo e($service->id); ?>">
                <input class="btn btn-secondary" style="width:100px; background-color:#B74438 !important; float:right"type="submit" value="Reservar">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/bookings/schedule.blade.php ENDPATH**/ ?>