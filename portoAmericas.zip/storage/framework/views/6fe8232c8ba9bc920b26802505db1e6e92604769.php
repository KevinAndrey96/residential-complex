<?php echo e($slot); ?>

<?php /**PATH C:\xampp8\htdocs\portoAmericas\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>