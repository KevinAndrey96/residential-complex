<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <?php if(Session::has('updaservsuccess')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('updaservsuccess')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="card">
        <div class="card-header">
            Servicios
        </div>
        <div class="card-body container-fluid">
            <div class="justify-content-center" >
                <div class="col-auto mt-5">
                    <table class="table table-bordered table-responsive datatable" id="datatable">
                        <thead class="thead-light">
                        <tr>
                            <th style="text-align: center; padding:10px;">Título</th>
                            <th style="text-align: center; padding:10px;">Descripción</th>
                            <th style="text-align: center; padding:10px;">Capacidad</th>
                            <th style="text-align: center; padding:10px;">Franja</th>
                            <th style="text-align: center; padding:10px;">Hora de inicio</th>
                            <th style="text-align: center; padding:10px;">Hora de cierre</th>
                            <th style="text-align: center; padding:10px;">Estado</th>
                            <th style="text-align: center; padding:10px;">Días Hábiles</th>
                            <th style="text-align: center; padding:10px;">Acción</th>
                        </tr>
                        <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center; padding:10px;"> <?php echo e($service->title); ?></td>
                                    <td style="text-align: center; padding:10px;"> <?php echo e($service->description); ?></td>
                                    <td style="text-align: center; padding:10px;"> <?php echo e($service->capacity); ?></td>
                                    <td style="text-align: center; padding:10px;"> <?php echo e($service->strip); ?> minutos</td>
                                    <td style="text-align: center; padding:10px;"> <?php echo e($service->start); ?></td>
                                    <td style="text-align: center; padding:10px;"> <?php echo e($service->final); ?></td>
                                    <td style="text-align: center; padding:10px;">
                                        <?php if($service->state): ?>
                                            Habilitado
                                        <?php else: ?>
                                            Deshabilitado
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: center; padding:10px;">
                                        <ul>
                                            <?php if($service->monday == 1): ?> <li> Lunes </li> <?php endif; ?>
                                            <?php if($service->tuesday == 1): ?> <li> Martes </li> <?php endif; ?>
                                                <?php if($service->wednesday == 1): ?> <li> Miércoles </li> <?php endif; ?>
                                                <?php if($service->thursday == 1): ?> <li> Jueves </li> <?php endif; ?>
                                                <?php if($service->friday == 1): ?> <li> Viernes </li> <?php endif; ?>
                                                <?php if($service->saturday == 1): ?> <li> Sábado </li> <?php endif; ?>
                                                <?php if($service->sunday == 1): ?> <li> Domingo </li> <?php endif; ?>

                                        </ul>
                                    </td>
                                    <td style="text-align: center; padding:10px;">
                                        <div class="btn-group">
                                            <form method="POST" action="/services/edit">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value=<?php echo e($service->id); ?>>
                                                <input style="margin:3px; width:50%;" class="btn btn-warning btn-block" type="submit" value ="Editar">
                                            </form>
                                            <form method="POST" action="/services/delete">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value=<?php echo e($service->id); ?>>
                                                <input style="margin:3px; width:50%;" class="btn btn-danger btn-block" type="submit" onclick="return confirm('Esta seguro que quiere borrar el servicio?');" value ="Eliminar">
                                            </form>
                                        </div>
                                    </td>
                                </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/services/index.blade.php ENDPATH**/ ?>