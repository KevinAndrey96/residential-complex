<?php $__env->startSection('content'); ?>
    <?php if(Session::has('changePasswordSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('changePasswordSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('changePasswordFail')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(Session::get('changePasswordFail')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            Cambiar contraseña
        </div>
        <div class="card-body">
            <form method="POST" action="/changePassword">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="oldPassword">Escriba su antigua contraseña:</label>
                    <input type="password" class="form-control" name="oldPassword" required>
                </div>
                <div class="form-group">
                    <label for="newPassword">Escriba su nueva contraseña:</label>
                    <input type="password" class="form-control" name="newPassword" required>
                </div>
                <input style="float:right" type="submit" class="btn btn-danger" value="Cambiar contraseña">
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/users/changePassword.blade.php ENDPATH**/ ?>