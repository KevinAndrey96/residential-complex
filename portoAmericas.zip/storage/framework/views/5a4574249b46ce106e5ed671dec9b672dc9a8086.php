<?php $__env->startSection('content'); ?>
    <?php if(Session::has('addTransportSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('addTransportSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('deleteTransportSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('deleteTransportSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('createPetSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('createPetSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('deletePetSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('deletePetSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('createHabitantSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('createHabitantSuccess')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('deleteHabitantSuccess')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('deleteHabitantSuccess')); ?>

        </div>
    <?php endif; ?>


    <div class="card">
        <div class="card-header">
            Información extra
        </div>
        <div class="card-body container-fluid" >
            <?php if($user->extrainfo == 1): ?>

            <h1>Interior <?php echo e($user->resident->tower); ?>-Apartamento <?php echo e($user->resident->apt); ?></h1>
            <br/>
            <br/>
            <br/>
            <h3>Datos del residente</h3>
            <br/>
            <br/>
            <p style="font-size: 16px"><b>Nombre: </b> <?php echo e($residentData->name); ?></p>
            <p style="font-size: 16px"><b>Tipo de residente: </b> <?php echo e($residentData->residenttype); ?></p>
            <p style="font-size: 16px"><b>Tipo de documento: </b> <?php echo e($residentData->document_type); ?></p>
            <p style="font-size: 16px"><b>Número de documento: </b> <?php echo e($residentData->document); ?></p>
            <p style="font-size: 16px"><b>Número de teléfono: </b> <?php echo e($residentData->phone); ?></p>
            <p style="font-size: 16px"><b>Número de celular: </b> <?php echo e($residentData->mobile); ?></p>
            <p style="font-size: 16px"><b>Email: </b> <?php echo e($residentData->email); ?></p>
            <p style="font-size: 16px"><b>Actividad económica: </b> <?php echo e($residentData->job); ?></p>
            <p style="font-size: 16px"><b>Dirección adicional de notificaciones: </b> <?php echo e($residentData->address); ?></p>
                <?php if($residentData->residenttype == 'Arrendatario'): ?>
                    <p style="font-size: 16px"><b>Fecha de ingreso a la copropiedad: </b> <?php echo e($residentData->dateadmission); ?></p>
                <?php endif; ?>
                <p style="font-size: 16px"><b>Cómo desea participar: </b> <?php echo e($residentData->howcontribute); ?></p>
            <p style="font-size: 16px"><b>Temas de convivencia que le gustaría que se enviará a su correo  electrónico: </b></p>
            <ol>
                <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><p style="font-size: 16px"><?php echo e($theme); ?></p></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
            <p style="font-size: 16px"><b>Número de depósito: </b> <?php echo e($residentData->depositnum); ?></p>
            <p style="font-size: 16px"><b>Número de tarjeta de acceso: </b> <?php echo e($residentData->cardnum); ?></p>
                <?php if($residentData->residenttype == 'Propietario'): ?>
                <p style="font-size: 16px"><b>Vive actualmento en la propiedad: </b>
                    <?php if($residentData->livein == 1): ?>
                        Si
                    <?php else: ?>
                        No
                    <?php endif; ?>
                </p>
                <?php endif; ?>
                <?php if($residentData->residenttype == 'Propietario'): ?>
                <p style="font-size: 16px"><b>Desea recibir toda la información de la propiedad y/o posibles llamados de atención a sus arrendatarios: </b>
                <?php if($residentData->lesseealert == 1): ?>
                    Si
                <?php else: ?>
                    No
                <?php endif; ?>

                </p>
                <?php endif; ?>
            <hr>
            <br/>
            <br/>
            <h3>Información núcleo familiar</h3>
                <div class="justify-content-center" >
                        <div class="col-auto mt-5">
                        <div class="row">
                            <a style="margin:15px; float: left; background-color:#B74438 !important;" class="btn btn-danger" href="/habitants/create/<?php echo e($user->id); ?>">Crear habitante</a>
                        </div>
                        <table class="table table-bordered table-responsive justify-content-center dataTable" id="datatable" cellspacing="0">
                            <thead>
                                <tr style="text-align: center;">
                                    <th>Nombre</th>
                                    <th>Tipo de documento</th>
                                    <th>Número de documento</th>
                                    <th>Edad</th>
                                    <th>Ocupación</th>
                                    <th>Parentesco con el residente</th>
                                    <th>Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $habitants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habitant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="text-align: center;">
                                    <td><?php echo e($habitant->name); ?></td>
                                    <td><?php echo e($habitant->document_type); ?></td>
                                    <td><?php echo e($habitant->document); ?></td>
                                    <td><?php echo e($habitant->age); ?> años</td>
                                    <td><?php echo e($habitant->occupation); ?></td>
                                    <td><?php echo e($habitant->kinship); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a style="margin:3px; width:50%; color:white;"  class="btn btn-danger btn-block" href="/habitants/delete/<?php echo e($habitant->id); ?>" onclick="return confirm('¿Esta seguro que quiere borrar este habitante?')">Eliminar</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                </div>
                <hr>
                <br/>
                <br/>
                <h3>Información parqueaderos</h3>
                <div class="justify-content-center" >
                    <div class="col-auto mt-5">
                        <div class="row">
                            <a style="margin:15px; float: left; background-color:#B74438 !important;" class="btn btn-danger" href="/transports/create/<?php echo e($user->id); ?>">Añadir medio de transporte</a>
                        </div>
                        <table class="table table-bordered table-responsive justify-content-center" id="datatable1" >
                            <thead>
                            <tr style="text-align: center;">
                                <th>Tipo</th>
                                <th>Marca</th>
                                <th>Color</th>
                                <th>Modelo</th>
                                <th>Placa</th>
                                <th>No. Parqueadero</th>
                                <th>Parqueadero propio</th>
                                <th>No. de Serie</th>
                                <th>No. Bicicletero</th>
                                <th>Periodo de uso bicicletero</th>
                                <th>Acción</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $transports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="text-align: center;">
                                    <td>
                                        <?php if($transport->type == 'motorcycle'): ?>
                                            Motocicleta
                                        <?php elseif($transport->type == 'car'): ?>
                                            Carro
                                        <?php elseif($transport->type == 'bicycle'): ?>
                                            Bicicleta
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($transport->brand == null): ?>
                                            No aplica
                                        <?php else: ?>
                                            <?php echo e($transport->brand); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($transport->color); ?></td>
                                    <td>
                                        <?php if($transport->model == null): ?>
                                            No aplica
                                        <?php else: ?>
                                            <?php echo e($transport->model); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($transport->plaque == null): ?>
                                            No aplica
                                        <?php else: ?>
                                            <?php echo e(strtoupper($transport->plaque)); ?>

                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <?php if($transport->parkingnum == null): ?>
                                            No aplica
                                        <?php else: ?>
                                            <?php echo e($transport->parkingnum); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($transport->ownparking == null): ?>
                                            No aplica
                                        <?php elseif($transport->ownparking == 'yes'): ?>
                                            Si
                                        <?php elseif($transport->ownparking == 'no'): ?>
                                            No
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($transport->numserie == null): ?>
                                            No aplica
                                        <?php else: ?>
                                            <?php echo e($transport->numserie); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($transport->bicyclerack == null): ?>
                                            No aplica
                                        <?php else: ?>
                                            <?php echo e($transport->bicyclerack); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($transport-> bicycleperiod == 0): ?>
                                            No aplica
                                        <?php else: ?>
                                            <?php echo e($transport-> bicycleperiod); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a style="margin:3px; width:50%; color:white;"  class="btn btn-danger btn-block" href="/transports/delete/<?php echo e($transport->id); ?>" onclick="return confirm('¿Esta seguro que quiere eliminar este medio de transporte?')">Eliminar</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <hr>
                <br/>
                <br/>
                <h3>Información mascotas</h3>
                <div class="justify-content-center" >
                    <div class="col-auto mt-5">
                        <div class="row">
                            <a style="margin:15px; float: left; background-color:#B74438 !important;" class="btn btn-danger" href="/pets/create/<?php echo e($user->id); ?>">Crear mascota</a>
                        </div>
                        <table class="table table-bordered table-responsive justify-content-center" id="datatable2" cellspacing="0">
                            <thead>
                            <tr style="text-align: center;">
                                <th>Nombre</th>
                                <th>Especie</th>
                                <th>Raza</th>
                                <th>Color</th>
                                <th>Edad</th>
                                <th>Poliza de seguro</th>
                                <th>Carnet de vacunas actualizado</th>
                                <th>Peligroso</th>
                                <th>Placa</th>
                                <th>Acción</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="text-align: center;">
                                    <td><?php echo e($pet->name); ?></td>
                                    <td>
                                        <?php if($pet->species == 'dog'): ?>
                                            Perro
                                        <?php elseif($pet->species == 'cat'): ?>
                                                Gato
                                        <?php else: ?>
                                            <?php echo e($pet->species); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($pet->race); ?></td>
                                    <td><?php echo e($pet->color); ?></td>
                                    <td><?php echo e($pet->age); ?> años</td>
                                    <td><?php echo e($pet->policy); ?></td>
                                    <td>
                                        <?php if($pet->card == 1): ?>
                                            Si
                                            <?php else: ?>
                                            No
                                        <?php endif; ?>


                                    </td>
                                    <td>
                                        <?php if($pet->dangerous == 1): ?>
                                            Si
                                        <?php else: ?>
                                            No
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($pet->plaque == 1): ?>
                                            Si
                                        <?php else: ?>
                                            No
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a style="margin:3px; width:50%; color:white;"  class="btn btn-danger btn-block" href="/pets/delete/<?php echo e($pet->id); ?>" onclick="return confirm('¿Esta seguro que quiere borrar esta mascota?')">Eliminar</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <hr>
                <br/>
                <br/>
                <h3>Información para facturación</h3>
                <br/>
                <br/>
                <p style="font-size: 16px"><b>Persona de contacto: </b> <?php echo e($residentData->name_invoice); ?></p>
                <p style="font-size: 16px"><b>Teléfono fijo / Teléfono celular: </b> <?php echo e($residentData->phone_invoice); ?></p>
                <p style="font-size: 16px"><b>Dirección de notificaciones: </b> <?php echo e($residentData->address_invoice); ?></p>
                <hr>
                <br/>
                <br/>
                <h3> Información inmobiliaria</h3>
                <br/>
                <br/>
                <p style="font-size: 16px"><b>Razón Social: </b> <?php echo e($residentData->razon_realestate); ?></p>
                <p style="font-size: 16px"><b>Nit: </b> <?php echo e($residentData->nit_realestate); ?></p>
                <p style="font-size: 16px"><b>Nombre de contacto: </b> <?php echo e($residentData->name_realestate); ?></p>
                <p style="font-size: 16px"><b>E-mail de contacto: </b> <?php echo e($residentData->email_realestate); ?></p>
                <p style="font-size: 16px"><b>Teléfono: </b> <?php echo e($residentData->phone_realestate); ?></p>
                <hr>
        </div>
            <?php else: ?>
                <h1><i>El residente no ha llenado el formulario</i></h1>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\portoAmericas\resources\views/extrainfo/index.blade.php ENDPATH**/ ?>