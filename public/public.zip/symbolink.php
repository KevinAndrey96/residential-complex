<?php
symlink('/home/portoamericas/portoamericas/storage/app/public', '/home/portoamericas/portal.portoamericas.com/storage');
